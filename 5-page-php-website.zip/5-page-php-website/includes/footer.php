<!--- Start Footer -->

	<footer>
		<div class="container">
			<div class="row text-center py-5">
				<div class="col-md-4">
					<img src="img/bootstrap.png">
					<p>At our core is a collection of design and development solutions that represent everything your business needs to compete in the modern marketplace.</p>
				</div>
				<div class="col-md-4">
					<h3 class="text-center">CONTACT INFO</h3><strong>Contact Info</strong>
					<p>(888) 888-8888<br>
					email@nuno.com</p>
				</div>
				<div class="col-md-4 pb-5">
					<h3 class="text-center">CONNECT WITH US</h3><br>
					<a class="btn btn-outline-light btn-lg" href="#">SEND US AN EMAIL</a>
				</div>
			</div><!--- End of Row -->
		</div><!--- End of Container -->
	</footer>

	<!--- End of Footer -->